-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Client :  flyannonyc1.mysql.db
-- Généré le :  Jeu 05 Janvier 2017 à 22:02
-- Version du serveur :  5.5.52-0+deb7u1-log
-- Version de PHP :  5.4.45-0+deb7u6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `flyannonyc1`
--

-- --------------------------------------------------------

--
-- Structure de la table `tbl_classified`
--

CREATE TABLE IF NOT EXISTS `tbl_classified` (
  `classified_id` int(11) NOT NULL,
  `mem_id` int(11) NOT NULL,
  `classified_city_id` int(11) NOT NULL DEFAULT '0',
  `clsd_cat_id` int(11) NOT NULL DEFAULT '0',
  `clsd_subcat_id` int(11) NOT NULL DEFAULT '0',
  `clsd_sub_subcat_id` int(11) NOT NULL,
  `classified_key` varchar(50) NOT NULL DEFAULT '',
  `classified_poster_name` varchar(50) NOT NULL,
  `classified_poster_email` varchar(200) NOT NULL DEFAULT '',
  `classified_type` varchar(200) NOT NULL,
  `classified_title` varchar(255) NOT NULL DEFAULT '',
  `classified_desc` text NOT NULL,
  `classified_price_option` int(11) NOT NULL,
  `classified_poster_street` text NOT NULL,
  `classified_poster_state` int(11) NOT NULL DEFAULT '0',
  `classified_poster_zipcode` varchar(30) NOT NULL DEFAULT '',
  `contact_number` varchar(100) NOT NULL,
  `classi_fax` varchar(100) NOT NULL,
  `classified_post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `classified_update_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `classified_expired_date` date NOT NULL DEFAULT '0000-00-00',
  `feature_expired_date` date NOT NULL,
  `classified_status` enum('Active','Inactive','Delete','Tempr') DEFAULT 'Active',
  `classified_featured` enum('Yes','No') NOT NULL DEFAULT 'No',
  `paid_status` enum('Pending','Paid','Free') NOT NULL DEFAULT 'Free',
  `paid_cat_amount` float(10,2) NOT NULL,
  `feature_admount` float(10,2) NOT NULL,
  `classified_visit` int(11) NOT NULL DEFAULT '0',
  `classified_contact` int(11) NOT NULL DEFAULT '0',
  `classified_mostpopular` enum('Yes','No') NOT NULL DEFAULT 'No',
  `contact_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `offer` varchar(50) NOT NULL,
  `date_fin_urgent` datetime NOT NULL,
  `date_fin_premium` datetime NOT NULL,
  `date_fin_couleur` datetime NOT NULL,
  `date_fin_republication` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `tbl_classified`
--
ALTER TABLE `tbl_classified`
  ADD PRIMARY KEY (`classified_id`),
  ADD KEY `clsd_sub_subcat_id` (`clsd_sub_subcat_id`),
  ADD KEY `clsd_subcat_id` (`clsd_subcat_id`),
  ADD KEY `clsd_cat_id` (`clsd_cat_id`),
  ADD KEY `classified_city_id` (`classified_city_id`),
  ADD KEY `mem_id` (`mem_id`),
  ADD KEY `classified_key` (`classified_key`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `tbl_classified`
--
ALTER TABLE `tbl_classified`
  MODIFY `classified_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
